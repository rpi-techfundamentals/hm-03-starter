test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> AgeMedianTrain
          28.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> AgeMedianTest
          27.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> AgeMissingTrain
          177
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> AgeMissingTest
          86
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
